import LoginPage from "@/components/login/LoginPage";

export default function HomePage() {
  return <LoginPage />;
}