import AdminGuard from "@/components/admin/AdminGuard";
import DeviceManagement from "@/components/devices/DeviceManagement";

export default function AdminDevicesPage() {
  return (
    <AdminGuard>
      <main className="min-h-screen bg-slate-50 p-4 md:p-6 lg:p-8">
        <div className="mx-auto max-w-[1440px]">
          <header className="mb-6">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-teal-700">Administration / Device registry</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900 md:text-3xl">อุปกรณ์และการจับคู่ผู้ป่วย</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">ลงทะเบียนรหัสอุปกรณ์ ตรวจสอบสถานะการเชื่อมต่อ และจับคู่อุปกรณ์กับการเข้ารักษา (UWID) ของผู้ป่วย</p>
          </header>
          <DeviceManagement />
        </div>
      </main>
    </AdminGuard>
  );
}
